import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  serverElements=[{type:'server',name:'Tester server ', desc:'jsut a test'}];
  constructor(){}
  
  onServerAdded(serverData:{serverName:string, serverContent:string}){
    this.serverElements.push({ 
      name:serverData.serverName, //1
      desc:serverData.serverContent, //2 :: 1 n 2 are propeties should be passed from cockpit cmpnt
      type:"server"
    });
// 3 in appcmp html selctor should be passed with events
  }
  onBlueprintAdded(blueprintData:{serverName:string, serverContent:string}){
    this.serverElements.push({
      type:'blue',
      name:blueprintData.serverName, //1
      desc:blueprintData.serverContent, //2 :: 1 n 2 are propeties should be passed from cockpit cmpnt
    })
  }
}
